type Alert = {
  ts: string;
  title: string;
  severity: "low" | "medium" | "high" | "critical";
  summary: string;
};

export default function AlertStream({ alerts }: { alerts: Alert[] }) {
  return (
    <div className="h-full min-h-0 overflow-auto rounded-2xl border bg-white p-4 dark:bg-zinc-950 dark:border-zinc-800">
      <div className="mb-2 text-sm font-semibold text-black dark:text-white">
        Alert Stream
      </div>
      {alerts.length === 0 ? (
        <div className="text-sm text-gray-600 dark:text-zinc-400">No alerts yet.</div>
      ) : (
        <div className="space-y-3">
          {alerts.map((a, i) => (
            <div key={i} className="rounded-xl border p-3 dark:border-zinc-800">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold text-black dark:text-white">
                  {a.title}
                </div>
                <div className="text-xs text-gray-500 dark:text-zinc-500">{a.ts}</div>
              </div>
              <div className="mt-1 text-sm text-gray-700 dark:text-zinc-300">
                {a.summary}
              </div>
              <div className="mt-2 text-xs font-semibold">{a.severity.toUpperCase()}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}