import ThemeToggle from "./ThemeToggle";
import LoginButton from "./LoginButton";

export default function TopBar() {
  return (
    <div className="mb-4 flex items-center justify-between">
      <div>
        <div className="text-2xl font-bold tracking-tight text-black dark:text-white">
          SOC Console
        </div>
        <div className="text-sm text-gray-600 dark:text-zinc-400">
          Conversational SIEM Assistant • LIVE DEMO
        </div>
      </div>

      <div className="flex items-center gap-2">
        <LoginButton />
        <ThemeToggle />
      </div>
    </div>
  );
}