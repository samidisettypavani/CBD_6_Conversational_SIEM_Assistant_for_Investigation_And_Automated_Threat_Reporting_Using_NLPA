"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

type Msg = { role: "user" | "assistant"; content: string };

type Entity = { type: string; value: string; confidence?: number };

type ServerResponse = {
  assistant_text: string;
  investigation_plan: {
    detected_entities: Entity[];
    severity?: "low" | "medium" | "high" | "critical";
    [k: string]: any;
  };
  execution?: {
    matched: any[];
    stats: {
      total: number;
      byEventType: Record<string, number>;
      bySeverity: Record<string, number>;
      topSourceIps: { value: string; count: number }[];
      topUsers: { value: string; count: number }[];
      timeWindowUsed: string;
      bruteForceDetected: boolean;
      topHosts: { value: string; count: number }[];
    };
  };
};

export default function Chat({
  onPlan,
}: {
  onPlan: (payload: ServerResponse) => void;
}) {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Hi! I’m your SIEM assistant. Try: “Show suspicious login attempts in the last 24 hours.”",
    },
  ]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const quickPrompts = useMemo(
    () => [
      "List failed login attempts in the last 24 hours",
      "What indicators suggest a brute-force attack?",
      "How should I triage repeated login failures from one IP?",
      "Generate a short incident summary for suspicious logins",
    ],
    []
  );

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || isSending) return;
  
    const newMessages: Msg[] = [...messages, { role: "user", content: trimmed }];
    setMessages(newMessages);
    setInput("");
    setIsSending(true);
  
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newMessages }),
      });
  
      const data = await res.json();
  
      if (!res.ok) {
        throw new Error(data?.error || "Request failed");
      }
  
      // ✅ success payload now contains assistant_text + investigation_plan
      const payload = data as ServerResponse;
  
      const assistantMsg: Msg = {
        role: "assistant",
        content: payload.assistant_text,
      };
  
      setMessages([...newMessages, assistantMsg]);
      onPlan(payload);
    } catch (e) {
      const errorMsg: Msg = {
        role: "assistant",
        content:
          "Error: I couldn’t reach the model. Check your API key and server logs.",
      };
      setMessages([...newMessages, errorMsg]);
      console.error(e);
    } finally {
      setIsSending(false);
    }
  }

  return (
    <div className="h-full min-h-0 rounded-2xl border border-gray-300 bg-white shadow-sm flex flex-col">
      <div className="shrink-0 border-b p-4">
        <div className="text-lg font-semibold text-black">Conversational SIEM Assistant</div>
        <div className="text-sm text-gray-500">
          Phase 1: Frontend + Gemini (no real logs yet)
        </div>
      </div>
    
      <div className="shrink-0 flex gap-2 overflow-x-auto border-b p-3">
        {quickPrompts.map((p) => (
          <button
            key={p}
            className="whitespace-nowrap rounded-full border px-3 py-1 text-sm text-black hover:bg-gray-50"
            onClick={() => sendMessage(p)}
            disabled={isSending}
            type="button"
          >
            {p}
          </button>
        ))}
      </div>
      
      <div className="flex-1 min-h-0 overflow-auto p-4">
        <div className="space-y-3">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm leading-relaxed ${
                  m.role === "user"
                    ? "bg-black text-white"
                    : "bg-gray-100 text-gray-900"
                }`}
              >
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
              </div>
            </div>
          ))}
  
          {isSending && (
            <div className="flex justify-start">
              <div className="rounded-2xl bg-gray-100 px-4 py-2 text-sm text-gray-700">
                Thinking…
              </div>
            </div>
          )}
  
          <div ref={endRef} />
        </div>
      </div>
        
      <form
        className="shrink-0 border-t p-3"
        onSubmit={(e) => {
          e.preventDefault();
          sendMessage(input);
        }}
      >
        <div className="flex gap-2">
          <input
            className="flex-1 rounded-xl border px-3 py-2 text-sm text-black outline-none focus:ring-2 focus:ring-black/10"
            placeholder='Try: "Summarize suspicious activity for the past day"'
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isSending}
          />
          <button
            className="rounded-xl bg-black px-4 py-2 text-sm text-white disabled:opacity-50"
            disabled={isSending || !input.trim()}
            type="submit"
          >
            Send
          </button>
        </div>
      </form>
    </div>
  );
}