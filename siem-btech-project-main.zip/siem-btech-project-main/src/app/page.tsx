"use client";

import { useState } from "react";
import Chat from "./components/Chat";
import DashboardPanel from "./components/DashboardPanel";
import TopBar from "./components/TopBar";
import AlertStream from "./components/AlertStream";
import { useAuth } from "./components/AuthProvider";
import { db } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

type Entity = { type: string; value: string; confidence?: number };
type Alert = {
  ts: string;
  title: string;
  severity: "low" | "medium" | "high" | "critical";
  summary: string;
};

export default function Home() {
  const [entities, setEntities] = useState<Entity[]>([]);
  const [planPayload, setPlanPayload] = useState<any | null>(null);
  const [chatOpen, setChatOpen] = useState(true);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const { user, loading } = useAuth();
  const [execution, setExecution] = useState<any | null>(null);

  if (loading) {
    return (
      <main className="p-4">
        <TopBar />
        <div className="mt-8 text-sm text-gray-700 dark:text-zinc-300">Loading…</div>
      </main>
    );
  }

  if (!user) {
    return (
      <main className="p-4">
        <TopBar />
        <div className="mt-8 rounded-2xl border bg-white p-6 dark:bg-zinc-950 dark:border-zinc-800">
          <div className="text-lg font-semibold text-black dark:text-white">
            Sign in required
          </div>
          <div className="mt-1 text-sm text-gray-600 dark:text-zinc-400">
            Please sign in with Google to access the SOC console.
          </div>
          <div className="mt-4">
            {/* TopBar already includes LoginButton */}
            <span className="text-sm text-gray-600 dark:text-zinc-400">
              Use the “Sign in with Google” button in the top right.
            </span>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="h-screen overflow-hidden p-4">
      <div className="flex h-full flex-col gap-4">
        {/* TopBar always visible */}
        <div className="shrink-0">
          <TopBar />
        </div>

        {/* Remaining area */}
        <div className="grid flex-1 min-h-0 grid-cols-12 gap-4">
          {/* Left */}
          <div className="col-span-8 flex min-h-0 flex-col gap-4">
            <div className="flex-[7] min-h-0">
              <DashboardPanel entities={entities} plan={planPayload} execution={execution}/>
            </div>
            <div className="flex-[3] min-h-0">
              <AlertStream alerts={alerts} />
            </div>
          </div>

          {/* Right */}
          <div className="col-span-4 flex min-h-0 flex-col">
            {/* Header row */}
            <div className="shrink-0 mb-2 flex items-center gap-2">
              <button
                onClick={() => setChatOpen((v) => !v)}
                className="rounded-lg border px-2 py-1 text-xs text-black hover:bg-gray-50
                           dark:border-zinc-700 dark:text-white dark:hover:bg-zinc-800"
                type="button"
                title={chatOpen ? "Minimize chat" : "Maximize chat"}
              >
                {chatOpen ? "▁" : "▢"}
              </button>
              <div className="text-sm font-semibold text-black dark:text-white">
                Chat
              </div>
            </div>

            {/* Chat area */}
            <div className="relative flex-1 min-h-0">
              {/* Chat stays mounted always (so state is preserved) */}
              <div className={chatOpen ? "h-full" : "hidden"}>
                <Chat
                  onPlan={(payload) => {
                    setPlanPayload(payload);
                    setEntities(payload.investigation_plan.detected_entities ?? []);
                    setExecution(payload.execution ?? null);
                  
                    setAlerts((prev) =>
                      [
                        {
                          ts: new Date().toLocaleTimeString(),
                          title: payload.investigation_plan.intent
                            .replaceAll("_", " ")
                            .toUpperCase(),
                          severity: payload.investigation_plan.severity ?? "medium",
                          summary: payload.assistant_text.slice(0, 120) + "…",
                        },
                        ...prev,
                      ].slice(0, 20)
                    );
                  }}
                />
              </div>
                
              {/* Collapsed bar (only when minimized) */}
              {!chatOpen && (
                <button
                  onClick={() => setChatOpen(true)}
                  className="absolute bottom-0 left-0 right-0 flex items-center justify-between
                             rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-black
                             hover:bg-gray-50 dark:bg-zinc-950 dark:border-zinc-800 dark:text-white dark:hover:bg-zinc-900"
                  type="button"
                  title="Open chat"
                >
                  <span>Chat minimized</span>
                  <span className="rounded-lg border px-2 py-1 text-xs dark:border-zinc-700">
                    ▢
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}